clear all; close all;

% perfiles: ejecutar el script varias veces

I = imread('Tema05a.jpg','jpeg');
figure; imshow(I(:,:,1)); impixelinfo

improfile 

